package game;

/**
 * @author Gavriel Zichron 206784407 Eliron Picard 322355678
 * @version 1
 * @since 31/07/2024
 */
public class Ass5Game {
    /**
     * main.
     * @param args argument from cmd.
     */
    public static void main(String[] args) {
        Game g = new Game();
        g.initialize();
        g.run();

    }
}
